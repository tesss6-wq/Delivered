const image = document.querySelectorAll('#img_cont img');
const changeBt = document.getElementById('auto');

let currentInde = 0;
let intervalI = null;


function changeImage() {
 
    image[currentInde].classList.remove('active');
    
    currentInde = (currentInde + 1) % image.length;
    

    image[currentInde].classList.add('active');
}


function toggleAutoChange() {
    if (intervalI) {
       
        clearInterval(intervalI);
        intervalI = null;
        changeBt.textContent = 'Запустить автосмену';
    } else {
       
        intervalI = setInterval(changeImage, 1000);
        changeBt.textContent = 'Остановить автосмену';
    }
}


changeBt.addEventListener('click', toggleAutoChange);


 intervalI = setInterval(changeImage, 1000);