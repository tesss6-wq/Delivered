
        const images = document.querySelectorAll('#image-container img');
        const changeBtn = document.getElementById('change-btn');
        
        let currentIndex = 0; 
        
      
        function changeImage() {
         
            images[currentIndex].classList.remove('active');
            
            currentIndex = (currentIndex + 1) % images.length;
            
            images[currentIndex].classList.add('active');
        }
        
       
        changeBtn.addEventListener('click', changeImage);

